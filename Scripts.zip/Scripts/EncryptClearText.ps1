﻿$ClearTextSecrets = Import-csv "$PSScriptRoot\ClearTextSecrets.csv"

$Passwords = @()
$ClearTextSecrets | ForEach-Object {

    $Secure = ConvertTo-SecureString -String $_.Secret -AsPlainText -Force
    $Passwords += New-Object psobject -Property ([ordered]@{

            Name   = $_.Name
            Secret = ConvertFrom-SecureString -SecureString $Secure
    
        })
}
$Passwords | Export-Csv "$PSScriptRoot\SecureSecrets.csv" -NoTypeInformation -Force