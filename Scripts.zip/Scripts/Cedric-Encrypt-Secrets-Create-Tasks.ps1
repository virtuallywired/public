﻿# Create a new task action
$taskAction = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument "-File $("$PSScriptRoot\EncryptClearText.ps1")"

# Register the new PowerShell scheduled task

# The name of your scheduled task.
$taskName = "Encrypt-Clear-Text-Secrets"

# Describe the scheduled task.
$description = "Encrypt Clear Text Secrets"

$taskPrincipal = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\SYSTEM" -RunLevel Highest

# Register the scheduled task
Register-ScheduledTask `
    -TaskName $taskName `
    -Action $taskAction `
    -Description $description `
    -Principal $taskPrincipal


Start-ScheduledTask -TaskName $taskName

Unregister-ScheduledTask -TaskName $taskName -Confirm:$false

Start-Sleep -Seconds 3

# Create a new task action
$taskAction = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument "-File $("$PSScriptRoot\Cedric-Install-vCenterSSL-Secrets.ps1")"

# Register the new PowerShell scheduled task

# The name of your scheduled task.
$taskName = "Install-vCenter-SSL-With-Encrypted-Secrets"

# Describe the scheduled task.
$description = "Generate SSL via Posh-ACME and Install vCenter-SSL With Encrypted Secrets"

$taskPrincipal = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\SYSTEM" -RunLevel Highest

# Register the scheduled task
Register-ScheduledTask `
    -TaskName $taskName `
    -Action $taskAction `
    -Description $description `
    -Principal $taskPrincipal